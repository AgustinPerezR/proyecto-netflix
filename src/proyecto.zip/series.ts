import { type Serie } from "./types.tsx";
import { type SeasonSerie } from "./types.tsx";

export const series: Serie[] = [
  {
    id: 1,
    type: "serie",
    title: "Breaking Bad",
    poster: "/Breaking Bad (2008).jpeg",
    // poster: "/series/breaking_bad/Breaking Bad (2008).jpg",
    color: "rgba(244, 189, 28, 0.8)",
    background:
      "https://image.tmdb.org/t/p/original/cFXxKJzGrvjcmMJAReNekx0RVJb.jpg",
    // "https://image.tmdb.org/t/p/original/lKODbE8ARPJEPnjTBfiIJ98I3YL.jpg",
    // "",
    seasons: 5,
    episodes: 62,
    creator: "Vince Gilligan",
    synopsis:
      "Un profesor de química se convierte en fabricante de metanfetaminas.",
    seasons_data: [
      {
        id_serie: 1,
        season_number: 1,
        year: 2008,
        poster: "/series/breaking_bad/Breaking Bad (2008) - Season 1.jpg",
        color: "rgba(62, 111, 140, 0.8)",
        episodes: 7,
      },
      {
        id_serie: 1,
        season_number: 2,
        year: 2009,
        poster: "/series/breaking_bad/Breaking Bad (2008) - Season 2.jpg",
        color: "rgba(180, 180, 170, 0.8)",
        episodes: 13,
      },
      {
        id_serie: 1,
        season_number: 3,
        year: 2010,
        poster: "/series/breaking_bad/Breaking Bad (2008) - Season 3.jpg",
        color: "rgba(244, 189, 28, 0.8)",
        episodes: 13,
      },
      {
        id_serie: 1,
        season_number: 4,
        year: 2011,
        poster: "/series/breaking_bad/Breaking Bad (2008) - Season 4.jpg",
        color: "rgba(160, 66, 64, 0.8)",
        episodes: 13,
      },
      {
        id_serie: 1,
        season_number: 5,
        year: 2012,
        poster: "/series/breaking_bad/Breaking Bad (2008) - Season 5.jpg",
        color: "rgba(103, 75, 50, 0.8)",
        episodes: 16,
      },
    ],
  },
  {
    id: 2,
    type: "serie",
    title: "Dark",
    poster: "Dark (2017).png",
    color: "rgba(255, 255, 255, 0.8)",
    background:
      "https://image.tmdb.org/t/p/original/8Xr6d9k2b1z5Z3c4e7j5f9ovAM9v.jpg",
    seasons: 3,
    episodes: 26,
    creator: "Baran bo Odar, Jantje Friese",
    synopsis: "",
    seasons_data: [],
  },
  {
    id: 3,
    type: "serie",
    title: "Daredevil",
    poster:
      "https://image.tmdb.org/t/p/original/5ND7iEoiDEaKBdE6ol5f9ovAM9v.jpg",
    color: "rgba(193, 20, 20, 0.8)",
    background:
      "https://image.tmdb.org/t/p/original/AbQoohUsJLlVpbctoAQ2BsZtPIc.jpg",
    // "https://image.tmdb.org/t/p/original/3JTheOV0ri8xkf2TWOpMupQeT4I.jpg",
    seasons: 3,
    episodes: 39,
    creator: "Steven S. DeKnight",
    synopsis:
      "Un abogado ciego lucha contra el crimen en Hell's Kitchen, Nueva York, como vigilante por la noche.",
    seasons_data: [],
  },
  {
    id: 4,
    type: "serie",
    title: "Better Call Saul",
    poster: "Better Call Saul (2015).jpg",
    color: "rgba(249, 223, 149, 0.8)",
    background:
      "https://image.tmdb.org/t/p/original/8Xr6d9k2b1z5Z3c4e7j5f9ovAM9v.jpg",
    seasons: 6,
    episodes: 63,
    creator: "Vince Gilligan, Peter Gould",
    synopsis:
      "La historia de cómo Jimmy McGill se convierte en el abogado criminal Saul Goodman.",
    seasons_data: [],
  },
  {
    id: 5,
    type: "serie",
    title: "Invincible",
    poster:
      "https://image.tmdb.org/t/p/original/dMOpdkrDC5dQxqNydgKxXjBKyAc.jpg",
    color: "rgba(147, 56, 35, 0.8)",
    background:
      "https://image.tmdb.org/t/p/original/8Xr6d9k2b1z5Z3c4e7j5f9ovAM9v.jpg",
    seasons: 3,
    episodes: 24,
    creator: "Robert Kirkman",
    synopsis: "",
    seasons_data: [],
  },
  {
    id: 6,
    type: "serie",
    title: "Gravity Falls",
    poster: "Gravity Falls (2012).jpg",
    color: "rgba(134, 142, 100, 0.8)",
    background:
      "https://image.tmdb.org/t/p/original/8Xr6d9k2b1z5Z3c4e7j5f9ovAM9v.jpg",
    seasons: 2,
    episodes: 40,
    creator: "Alex Hirsch",
    synopsis:
      "Dos gemelos pasan el verano con su tío en un misterioso pueblo lleno de criaturas sobrenaturales.",
    seasons_data: [],
  },
  {
    id: 7,
    type: "serie",
    title: "El Eternauta",
    poster:
      "https://image.tmdb.org/t/p/original/9Krv5NvKa5a3Q3b1l2B3rP9Bj8E.jpg",
    color: "rgba(40, 145, 173, 0.8)",
    background:
      "https://image.tmdb.org/t/p/original/yMjGzK7L4gwzpQNNtFKDeG79upo.jpg",
    seasons: 1,
    episodes: 6,
    creator: "Bruno Stagnaro",
    synopsis: "",
    seasons_data: [],
  },
  {
    id: 8,
    type: "serie",
    title: "Silo",
    poster:
      "https://image.tmdb.org/t/p/original/xcCCQKnJqxkjDoDSMz4LmbKhCRP.jpg",
    color: "rgba(188, 160, 93, 0.8)",
    background:
      "https://image.tmdb.org/t/p/original/8Xr6d9k2b1z5Z3c4e7j5f9ovAM9v.jpg",
    seasons: 2,
    episodes: 20,
    creator: "Graham Yost",
    synopsis:
      "En un mundo subterráneo, los habitantes de un silo luchan por descubrir la verdad detrás de su existencia.",
    seasons_data: [],
  },
  {
    id: 9,
    type: "serie",
    title: "El Juego del Calamar",
    poster: "Squid Game (2021).jpg",
    color: "rgba(224, 139, 69, 0.8)",
    // color: "#ff0161",
    background:
      "https://image.tmdb.org/t/p/original/8Xr6d9k2b1z5Z3c4e7j5f9ovAM9v.jpg",
    seasons: 1,
    episodes: 9,
    creator: "Hwang Dong-hyuk",
    synopsis:
      "Un grupo de personas con problemas financieros acepta una misteriosa invitación para participar en un juego mortal.",
    seasons_data: [],
  },
];
