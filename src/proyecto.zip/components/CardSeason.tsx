import { type SeasonSerie } from "../types.tsx";
import React from "react";
import "./CardSeason.css";

type CardSeasonProps = {
  data: SeasonSerie;
  anterior?: React.RefObject<HTMLDivElement | null>;
  siguiente?: React.RefObject<HTMLDivElement | null>;
  index: number;
  totalCards: number;
  onCardHover?: (index: number) => void;
  onCardLeave?: () => void;
  hoveredIndex?: number | null;
};

const CardSeason = React.forwardRef<HTMLDivElement, CardSeasonProps>(
  (
    { data, index, totalCards, onCardHover, onCardLeave, hoveredIndex },
    ref
  ) => {
    const handleClick = () => {
      console.log("Card selected:", data.season_number, "Index:", index);
    };

    // Calcular z-index base y hover
    const calculateZIndex = () => {
      if (hoveredIndex === null || hoveredIndex === undefined) {
        const center = Math.floor(totalCards / 2);
        const distance = Math.abs(index - center);
        return 100 - distance;
      }

      const distance = Math.abs(index - hoveredIndex);
      return 100 - distance;
    };

    const zIndex = calculateZIndex();
    const zIndexHover = 999; // Z-index cuando está en hover
    const zIndexAdjacent = zIndex - 1; // Z-index para cartas adyacentes

    return (
      <div
        ref={ref}
        className="card-season w-64 cursor-pointer rounded-xl relative -ml-40 first:ml-0"
        tabIndex={0}
        style={
          {
            "--card-color": data.color,
            "--z-index": zIndex,
            "--z-index-hover": zIndexHover,
            "--z-index-adjacent": zIndexAdjacent,
          } as React.CSSProperties
        }
        onClick={handleClick}
        onKeyDown={(e) => {
          if (e.key === "Enter") {
            handleClick();
          }
        }}
        onMouseEnter={() => onCardHover?.(index)}
        // onMouseLeave={() => onCardLeave?.()}
      >
        <img
          src={data.poster}
          alt={String(data.season_number)}
          className="w-full h-full object-cover"
        />
      </div>
    );
  }
);

CardSeason.displayName = "CardSeason";

export default CardSeason;
