import { Search, Home as HomeIcon } from "lucide-react";

export default function Sidebar() {
  return (
    <aside className="w-14 bg-neutral-900 flex flex-col items-center py-4 space-y-4 border-r border-white/20">
      <button className="text-white hover:scale-110 transition-transform">
        <Search />
      </button>
      <button className="text-white hover:scale-110 transition-transform">
        <HomeIcon fill="#a5b4fc" />
      </button>
    </aside>
  );
}
