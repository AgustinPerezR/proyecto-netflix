import { Routes, Route } from "react-router-dom";
import Sidebar from "./components/Sidebar";
import Home from "./pages/Home";
import MoviePage from "./pages/MoviePage";
import SeriePage from "./pages/SeriePage";
import WatchVideoPage from "./pages/WatchVideoPage";

import { movies } from "./movies";

function preloadImages() {
  movies.forEach((movie) => {
    if (movie.poster) {
      const img = new Image();
      img.src = movie.poster;
    }
  });
}
preloadImages(); // ✅ Se ejecuta antes de renderizar cualquier componente

export default function App() {
  return (
    <div className="flex h-screen bg-black text-white">
      <Sidebar />
      <main className="flex-1 overflow-x-hidden">
        <Routes>
          <Route path="/" element={<Home />} />
          <Route path="/movie/:id" element={<MoviePage />} />
          <Route path="/serie/:id" element={<SeriePage />} />
          <Route path="/watch/:id" element={<WatchVideoPage />} />
        </Routes>
      </main>
    </div>
  );
}
