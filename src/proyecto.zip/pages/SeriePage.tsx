import { series } from "../series.ts";

import CarouselSeason from "../components/CarouselSeasonSerie.tsx";
import CardSeason from "../components/CardSeason.tsx";
import ButtonEpisode from "../components/ButtonEpisode.tsx";
import React from "react";
import { useParams } from "react-router-dom";
import { useNavigate } from "react-router-dom";
import { backgroundImage } from "flowbite-react/plugin/tailwindcss/theme";

import { useState, useRef } from "react";

type Props = {
  id?: number;
};

export default function SeriePage({ id }: Props) {
  const params = useParams();
  const numericId = id ?? Number(params.id);
  const serie = series.find((m) => m.id === numericId);
  const cardRefs = useRef<React.RefObject<HTMLDivElement | null>[]>([]);
  const navigate = useNavigate();
  const DEFAULT_SELECTED_CARD = 0;

  // Estado para el hover
  const [hoveredCardIndex, setHoveredCardIndex] = useState<number | null>(
    DEFAULT_SELECTED_CARD
  );
  // Funciones para manejar hover
  const handleCardHover = (index: number) => {
    setHoveredCardIndex(index);
  };

  const handleCardLeave = () => {
    setHoveredCardIndex(null);
  };

  // Inicializar refs para cada temporada
  if (serie?.seasons_data) {
    cardRefs.current = serie.seasons_data.map(() =>
      React.createRef<HTMLDivElement>()
    );
  }

  if (!serie) {
    return (
      <p className="text-center text-red-500 mt-10 font-handwritten">
        Serie no encontrada.
      </p>
    );
  } else if (!serie.seasons_data || serie.seasons_data.length === 0) {
    return (
      <div
        className=" px-8 pt-2 flex flex-col min-h-screen"
        style={{
          backgroundImage: `radial-gradient(ellipse at center, transparent 40%, rgba(0, 0, 0, 0.7) 90%), url(${serie.background})`,
          backgroundSize: "cover",
          backgroundPosition: "center",
          backgroundRepeat: "no-repeat",
        }}
      >
        {/* Botón volver */}
        <button
          onClick={() => navigate("/")}
          className="bg-black/50 hover:bg-black/70 text-white p-2 rounded-full w-fit"
          aria-label="Volver al inicio"
        >
          ←
        </button>
        <p className="text-center text-red-500 mt-10 font-handwritten">
          Serie no encontrada.
        </p>
      </div>
    );
  }

  return (
    <div
      className=" px-8 pt-2 flex flex-col min-h-screen"
      style={{
        backgroundImage: `radial-gradient(ellipse at center, transparent 40%, rgba(0, 0, 0, 0.7) 90%), url(${serie.background})`,
        backgroundSize: "cover",
        backgroundPosition: "center",
        backgroundRepeat: "no-repeat",
      }}
    >
      {/* Botón volver */}
      <button
        onClick={() => navigate("/")}
        className="bg-black/50 hover:bg-black/70 text-white p-2 rounded-full w-fit"
        aria-label="Volver al inicio"
      >
        ←
      </button>

      {/* Sección principal (tres columnas en fila) */}
      <div className="flex text-white">
        {/* Columna izquierda - Poster */}
        <div className="flex flex-col items-center bg-black/40 p-4 rounded-xl basis-[20%]">
          <img
            src={serie.poster}
            alt={serie.title}
            // className="rounded-xl w-full aspect-[2/3] object-cover border border-white/30"
            className="poster rounded-xl w-full aspect-[2/3] object-cover border border-white/50"
            style={{ "--poster-color": serie.color } as React.CSSProperties}
          />
          <p className="mt-4 text-xl">{serie.episodes} episodios</p>
        </div>

        {/* Columna central - Información */}
        <div className="flex flex-col justify-start gap-4 bg-black/40 p-4 rounded-lg basis-[70%]">
          <h1 className="text-4xl font-bold">{serie.title}</h1>
          <p className="text-lg">{serie.synopsis}</p>
          <p className="text-md font-semibold">Creador: {serie.creator}</p>

          <div className="flex justify-center">
            <div className="carousel-container">
              <CarouselSeason>
                {serie.seasons_data.map((season, index) => (
                  <CardSeason
                    key={season.season_number}
                    ref={cardRefs.current[index]}
                    data={season}
                    index={index}
                    totalCards={serie.seasons_data.length}
                    anterior={
                      index > 0 ? cardRefs.current[index - 1] : undefined
                    }
                    siguiente={
                      index < serie.seasons_data.length - 1
                        ? cardRefs.current[index + 1]
                        : undefined
                    }
                    onCardHover={handleCardHover}
                    onCardLeave={handleCardLeave}
                    hoveredIndex={hoveredCardIndex}
                  />
                ))}
              </CarouselSeason>
            </div>
          </div>
        </div>
      </div>

      {/* Episodios debajo */}
      <div className="bg-white/10 p-4 rounded-lg">
        <h2 className="text-2xl font-bold text-white mb-4">
          Temporada {serie.seasons_data[0].season_number}
        </h2>
        <div className="flex flex-wrap gap-4">
          {serie.seasons_data[0] &&
            Array.from(
              { length: serie.seasons_data[0].episodes },
              (_, index) => (
                <ButtonEpisode
                  key={index + 1}
                  episodeNumber={index + 1}
                  seasonNumber={serie.seasons_data[0].season_number}
                  colorSeason={serie.color}
                />
              )
            )}
        </div>
      </div>
    </div>
  );
}
